<?php
$db = mysqli_connect("localhost", "root", "", "exam_management"); // server_name, username, password, database_name
// if (!$db)
// {
//     die ("Connection Failed: ". mysqli_connect_error());
// }
// echo "Connection Successful";
?>