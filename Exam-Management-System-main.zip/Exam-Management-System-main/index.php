<?php
include "connection.php";
@session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Exam Management System</title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="admin/img/favicon.png">

    <!-- Custom CSS -->
    <link href="style.css" rel="stylesheet" type="text/css">
</head>

<body id="page-top">
    <!-- Navigation-->
    <nav class="navbar" id="mainNav">
        <div class="contain">
            
            <section class="navbar-brand"><img src="university (1).png" alt="logo"> Online Exam Management System</section>
            <ul class="navbarlinks">
                <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
            </ul>
        </div>
    </nav>

    <!-- Masthead-->
        <div class="containers">
            <div class="w-100">
                <div class="col">
                    <h1 class="text">Test Your Knowledge and Skills</h1>
                    <hr class="divider" />
                </div>
                <div class="col-lg-8 align-self-baseline">
                    <p class="text-white-75">Utilize your skills with Objective and Descriptive Tests!</p>
                    <p class="text-white-75 mb-5"> Make youself ready for any Exams.</p>
                    <a class="btn btn-primary btn-xl" href="login.php">Get Started</a>
                </div>
            </div>
        </div>
    
    <!-- About-->
    <section class="page-section" id="about">
        <div class="container ">
            <div class="b">
                <div class="a">
                    <h2 class="">About This Project</h2>
                    <hr class="divider divider-light" />
                    <p class="text-white-90 mb-4">This is an in-house Project work undertaken in context of partial fulfillment in the Computer Science & Tech. Department for Exam. This Project ensures a safe and secure environment for students to test their Knowledge.</p>
                    <div class="mb-4" id="follow">Follow Me on :
                        <a id="github" href="https://github.com/itsNileshHere" target="_blank"><img src="student/img/GitHub.png"></a>
                        <a id="telegram" href="https://t.me/DsntMtter" target="_blank"><img src="student/img/Telegram.png"></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    

</body>
</html>