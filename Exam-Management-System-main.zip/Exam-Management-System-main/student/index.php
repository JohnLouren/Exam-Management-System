<?php
include "../connection.php";
?>
<!DOCTYPE html>
<html>

<head>
</head>
<body>
    <?php
    include "login.php"
    ?>
</body>

</html>